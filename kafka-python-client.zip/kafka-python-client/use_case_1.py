import json
import os
import time
from datetime import datetime

from confluent_kafka import Producer

# Update these configs based on your Confluent Cloud setup
conf = {
    'bootstrap.servers': 'pkc-l7pr2.ap-south-1.aws.confluent.cloud:9092',
    'security.protocol': 'SASL_SSL',
    'sasl.mechanism': 'PLAIN',
    'sasl.username': '5AANK45OYLX2URUY',
    'sasl.password': 'cfltvT3GETtzTD4c0XxqVZGaBd2kIMh7QJci+ODMY+r8j6e1OzU+SWuctNAlfgjg'
}

# Kafka topic name
topic = 'telemetry-periodic'

# Delivery callback for debugging
def delivery_report(err, msg):
    if err is not None:
        print(f"Delivery failed for record {msg.key()}: {err}")
    else:
        print(f"Record successfully produced to {msg.topic()} {msg} [{msg.partition()}] at offset {msg.offset()}")

# Initialize producer
producer = Producer(conf)

# Folder containing payload JSON files
payload_folder = 'use-case-1'

# Get all JSON files in sorted order
files = sorted([f for f in os.listdir(payload_folder) if f.endswith('.json')])

for file_name in files:
    file_path = os.path.join(payload_folder, file_name)

    with open(file_path, 'r') as f:
        payload = json.load(f)


    key = None
    if isinstance(payload, dict) and 'did' in payload:
        payload['did'] = '450' # changing the vehicle id dynamically
        key = str(payload['did'])

    now = datetime.now()

    payload['publishTime'] = now.strftime("%d-%m-%YT%H:%M:%S")

    payload_str = json.dumps(payload)

    producer.produce(topic, key=key, value=payload_str, callback=delivery_report)

    print(f"Sent: {file_name}")



    # Wait for 5 second between messages
    time.sleep(5)

# Flush all messages at the end
producer.flush()

print(f"Use Case 1 completed successfully.")

