# Python Client

This project contains a Python 3 application that publishes to a topic(telemetry-periodic) 

## Prerequisites

We assume that you already have Python 3 installed and the following dependencies installed:.

```shell
pip3 install -r requirements.txt
```

## Usage

You can execute the consumer script by running for use case 1:

```shell
python3 use_case_1.py
```

You can execute the consumer script by running for use case 2:

```shell
python3 use_case_2.py
```